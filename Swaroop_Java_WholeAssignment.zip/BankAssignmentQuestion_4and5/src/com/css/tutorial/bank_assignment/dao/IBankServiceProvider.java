package com.css.tutorial.bank_assignment.dao;

import com.css.tutorial.bank_assignment.dto.BankAccount;
import com.css.tutorial.bank_assignment.exceptions.InsufficientFundException;
import com.css.tutorial.bank_assignment.exceptions.InvalidAccountException;

public interface IBankServiceProvider {

	public boolean createAccount(String accountName);
	public BankAccount checkAccount(String accountNO)throws InvalidAccountException;
	double getBalance(String accountNo)throws InvalidAccountException;
	boolean depositMoney(BankAccount account, double amount)throws InvalidAccountException;
	boolean withdrawMoney(BankAccount account,double amount)throws InsufficientFundException,InvalidAccountException;
	boolean transferMoney(BankAccount fromAccount,BankAccount toAccount, double amount)throws InsufficientFundException,InvalidAccountException;	
}
