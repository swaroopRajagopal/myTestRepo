package com.css.tutorial.bank_assignment.exceptions;

public class InsufficientFundException extends Exception {
	public String errorMsg;

	public InsufficientFundException(String errorMsg) {
		super();
		this.errorMsg = errorMsg;
	}
	public InsufficientFundException() {
		super();
		this.errorMsg="Insufficient Funds...!";
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.errorMsg;
	}
	@Override
	public String toString() {
		return "ProductNotFoundException [errorMsg=" + errorMsg + "]";
	}
}
