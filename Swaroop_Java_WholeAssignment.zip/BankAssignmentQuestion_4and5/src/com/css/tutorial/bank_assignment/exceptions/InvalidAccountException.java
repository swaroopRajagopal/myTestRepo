package com.css.tutorial.bank_assignment.exceptions;

public class InvalidAccountException extends Exception {
	public String errorMsg="Account Number is Invalid";

//	Constructor.
	public InvalidAccountException(String errorMsg) {
		super();
		this.errorMsg = errorMsg;
	}

	public InvalidAccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

//	Overriding getMessage() method from SuperClass Exception. 
	@Override
	public String getMessage() {
		return this.errorMsg;
	}
//	Overriding toString() method.
	@Override
	public String toString() {
		return "InvalidAccountException [errorMsg=" + errorMsg + "]";
	}

	
	
}
