package com.css.tutorial.bank_assignment.main;

import java.util.HashSet;
import com.css.tutorial.bank_assignment.dto.Bank;
import com.css.tutorial.bank_assignment.dto.BankAccount;
import com.css.tutorial.bank_assignment.exceptions.InsufficientFundException;
import com.css.tutorial.bank_assignment.exceptions.InvalidAccountException;

public class Main {

	public static void main(String[] args) {

//		******************* Question 5.1 ***********
		
//		Creating a test Bank account. 
//		BankAccount[] testArray = new BankAccount[2];
//		testArray[0] = new BankAccount("1234", "Joe");
//		testArray[1] = new BankAccount("1235", "Sam");
//
////		populating the bankAccountArray using setters. 
//		Bank myBankAccount = new Bank();
//		myBankAccount.setBankAccountArray(testArray);
//		System.out.println(myBankAccount);
		
//		********************* Question 5.2 *************
//		Creating bank account with name. Account NO is automatically generated. 

		
//		Creating Bank Account using Arrays.
//		BankAccount[] bankAccountArray = new BankAccount[3];
//		bankAccountArray[0]= new BankAccount("Sara");
//		bankAccountArray[1]= new BankAccount("Joe");
//		bankAccountArray[2]= new BankAccount("Sam");


//		Creating Bank Accounts using Collections. 		
		HashSet<BankAccount> bankAccountSet = new HashSet<>();
		bankAccountSet.add(new BankAccount("Sara"));
		bankAccountSet.add(new BankAccount("Joe"));
		bankAccountSet.add(new BankAccount("Sam"));
		

//		Assigning the bank account array to the Bank. 
		Bank myBank = new Bank("Axis001","Axis Bank");
		myBank.setBankAccountSet(bankAccountSet);
		
//		********************** Question 5.3 ***************
//		Displaying Bank Accounts. 
		for(BankAccount account: myBank.getBankAccountSet() ) {
		System.out.println(account.toString());
		}
			
//		Check if Account number exists. 
		
		BankAccount checkAccount=tryCatchCheckAccount(myBank,""+1);
			
		if(checkAccount!= null) {
			System.out.println("\nAccount Found: \n     Account Number: "+checkAccount.getAccountNo()+"\n     Account Holders Name: "+checkAccount.getAccountName());	
		}else {
			System.out.println("Account Not found.\n");
		}
		
		
//		Get Balance
		try {
			System.out.println("\n     The account Balance is: "+myBank.getBalance(""+1)+"\n");
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int amt = 100; 
//		Deposit Money
		try {
			myBank.depositMoney(checkAccount, amt);
		} catch (InvalidAccountException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("\nThe current balance is: " +checkAccount.getBalance()+"\n");
		
		amt=200;
//		Withdraw Money
		try {
			myBank.withdrawMoney(checkAccount, 200);
		} catch (InsufficientFundException  | InvalidAccountException a ) {
			a.printStackTrace();
		}
		
		System.out.println("The current balance is: "+checkAccount.getBalance()+"\n");
				
		BankAccount fromAccount = tryCatchCheckAccount(myBank,""+1);
		BankAccount toAccount = tryCatchCheckAccount(myBank,""+2);
//		Transfer Money
		try {
			myBank.transferMoney( myBank.checkAccount(""+1),myBank.checkAccount(""+2), 100);
		} catch (InsufficientFundException|InvalidAccountException e) {
			e.printStackTrace();
		}
		System.out.println("The balance of the senders account: "+fromAccount.getBalance());
		System.out.println("The balance of the recipiants account: " +toAccount.getBalance());		
	}
	
	private static BankAccount tryCatchCheckAccount(Bank myBank,String accountNO) {
		
		try {
			return myBank.checkAccount(""+1);
		} catch (InvalidAccountException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			return null;
		}
	}

}
