package com.css.tutorial.bank_assignment.dto;

import java.util.HashSet;

import com.css.tutorial.bank_assignment.dao.IBankServiceProvider;
import com.css.tutorial.bank_assignment.exceptions.InsufficientFundException;
import com.css.tutorial.bank_assignment.exceptions.InvalidAccountException;

public class Bank implements IBankServiceProvider {

	
//	Adding IFSC code and Bank Name from the lecture. 
	private String IFSC;
	private String bankName;
	
	HashSet<BankAccount> bankAccountSet;

		
//	Constructor including IFSC and Bank Name
	public Bank(String iFSC, String bankName, HashSet<BankAccount> bankAccountSet) {
		super();
		IFSC = iFSC;
		this.bankName = bankName;
		this.bankAccountSet = bankAccountSet;
	}
	public Bank(HashSet<BankAccount> bankAccountSet) {
		super();
		this.bankAccountSet = bankAccountSet;
	}
	
	
	
//	To populate with setters.
	
	public Bank(String iFSC, String bankName) {
		super();
		IFSC = iFSC;
		this.bankName = bankName;
	}
	

	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
//	Gettes and setters for the IFSC and Name. 
	
	

	public String getIFSC() {
		return IFSC;
	}

	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public HashSet<BankAccount> getBankAccountSet() {
		return bankAccountSet;
	}
	public void setBankAccountSet(HashSet<BankAccount> bankAccountSet) {
		this.bankAccountSet = bankAccountSet;
	}
//	Override To String Method.

	@Override
	public String toString() {
		return "Bank [IFSC=" + IFSC + ", bankName=" + bankName + ", bankAccountSet=" + bankAccountSet + "]";
	}
	
	
	@Override
	public BankAccount checkAccount(String accountNO)throws InvalidAccountException {
		BankAccount foundAccount = null;
		for(BankAccount myAccount : this.bankAccountSet ) {
			if(myAccount.getAccountNo() .equals(accountNO)) {
				foundAccount=myAccount;
				break;
			}
		}
		if(foundAccount==null) {
			throw new InvalidAccountException();
		}
		return foundAccount;
	}

	@Override
	public double getBalance(String accountNO)throws InvalidAccountException {
		if(this.checkAccount(accountNO)!=null){
			return checkAccount(accountNO).getBalance();
		}else {
			throw new InvalidAccountException();	
		}
		
		
	}

	@Override
	public boolean depositMoney(BankAccount account, double amount) throws InvalidAccountException {
		boolean depositFlag =false;
		if(this.checkAccount(account.getAccountNo())!=null) {	
			account.setBalance(account.getBalance()+amount);
			depositFlag=true;
		}else {
			throw new InvalidAccountException();
		}
		return depositFlag;
	}

	@Override
	public boolean withdrawMoney(BankAccount account, double amount)throws InsufficientFundException, InvalidAccountException {
		boolean withdrawFlag=false;
		if(this.checkAccount(account.getAccountNo())!=null && account.getBalance()>=amount ) {
			account.setBalance(account.getBalance()-amount);
			withdrawFlag =true;
		}else {
			throw new InsufficientFundException();
		}
		return withdrawFlag;
	}
//	@Override
//	public boolean transferMoney(BankAccount fromAccount, BankAccount toAccount, double amount) {
//		boolean transferFlag = false;
//		if(this.checkAccount(fromAccount.getAccountNo())!=null && this.checkAccount(toAccount.getAccountNo())!= null){
//			if(fromAccount.getBalance() > amount) {
//			fromAccount.setBalance(fromAccount.getBalance()-amount);
//			toAccount.setBalance(toAccount.getBalance()+amount);
//			transferFlag=true;
//			}
//		}		
//		return transferFlag;
//	}
	@Override
	public boolean transferMoney(BankAccount fromAccount, BankAccount toAccount, double amount) throws InsufficientFundException, InvalidAccountException {
		boolean transferFlag = false;
		
		boolean withdrawFlag= this.withdrawMoney(fromAccount, amount);
		if(withdrawFlag) {
			boolean depositFlag= this.depositMoney(toAccount, amount);
			if(depositFlag)
				transferFlag=true;
			else {
				this.depositMoney(fromAccount, amount);
				throw new InsufficientFundException();
			}
		}
		return transferFlag;
	}

	@Override
	public boolean createAccount(String accountName) {
		// TODO Auto-generated method stub
		return false;
	}
}
