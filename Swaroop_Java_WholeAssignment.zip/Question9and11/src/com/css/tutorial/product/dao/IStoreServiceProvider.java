package com.css.tutorial.product.dao;

import com.css.tutorial.product.exceptions.ProductNotFoundException;

public interface IStoreServiceProvider {

	public double sellItem(String productCode,int qtyRequired) throws ProductNotFoundException;
	void updateStock(String productCode, int arrivedQty) throws ProductNotFoundException;
}
