package com.css.tutorial.product.exceptions;

public class ProductNotFoundException extends Exception {
	
	public String errorMsg;

	public ProductNotFoundException(String errorMsg) {
		super();
		this.errorMsg = errorMsg;
	}
	public ProductNotFoundException() {
		super();
		this.errorMsg="Peoduct Not Found...!";
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.errorMsg;
	}
	@Override
	public String toString() {
		return "ProductNotFoundException [errorMsg=" + errorMsg + "]";
	}
}
