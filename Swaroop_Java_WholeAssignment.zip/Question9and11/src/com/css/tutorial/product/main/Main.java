package com.css.tutorial.product.main;

import java.util.ArrayList;


import com.css.tutorial.product.dto.Product;
import com.css.tutorial.product.dto.Store;
import com.css.tutorial.product.exceptions.ProductNotFoundException;

public class Main {
	public static void main(String[] args) {
		ArrayList<Product> product= new ArrayList<>();
		product.add(new Product("1234", "Soap", 20.00, 60));
		product.add(new Product("1235", "Brush", 50.00, 50));
		product.add(new Product("1236", "Candle", 100.00, 10));
		
		Store myStore = new Store();
		myStore.setProduct(product);
		for(Product p: product) {
			System.out.println(p);
		}
		
//		Sell and Item. 
		double sellAmount=0;
		try {
			sellAmount=myStore.sellItem("1236", 2);
		} catch (ProductNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("==============================");
		System.out.println("The total amount is: "+sellAmount);
		for(Product p: product) {
			System.out.println(p);
		}
				
	}
}
