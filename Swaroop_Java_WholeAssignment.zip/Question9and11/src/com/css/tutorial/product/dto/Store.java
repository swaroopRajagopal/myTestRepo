package com.css.tutorial.product.dto;

import java.util.ArrayList;

import com.css.tutorial.product.dao.IStoreServiceProvider;
import com.css.tutorial.product.exceptions.ProductNotFoundException;

public class Store implements IStoreServiceProvider{
	private ArrayList<Product> product;

//Constructors.
	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Store(ArrayList<Product> product) {
		super();
		this.product = product;
	}
// Getters and Setters.
	public ArrayList<Product> getProduct() {
		return product;
	}

	public void setProduct(ArrayList<Product> product) {
		this.product = product;
	}
// Override ToString Method.
	@Override
	public String toString() {
		return "Store [product=" + product + "]";
	}

	@Override
	public double sellItem(String productCode, int qtyRequired) throws ProductNotFoundException {
		boolean sellFlag =false;
		double sellAmount =0;
		for(Product p: this.product) {
			if(p.getProductID().equals(productCode)) {
				p.setQuantityOnHand(p.getQuantityOnHand()-qtyRequired);
				sellFlag=true;
				sellAmount=p.getPrice()*qtyRequired;
				if(p.getReorderLevel()>qtyRequired) {
					updateStock(productCode, p.getReorderQty());
				}
			}
			
		}
		if(!sellFlag) {
			throw new ProductNotFoundException();
		}
		return sellAmount;
	}
	@Override
	public void updateStock(String productCode, int arrivedQty) throws ProductNotFoundException {
		boolean updateFlag =false;
		for(Product p: this.product) {
			if(p.getProductID().equals(productCode)) {	
				System.out.println("==============================\npurchase order is made.");
				updateFlag =true;
			}
		}
		if(!updateFlag) {
			throw new ProductNotFoundException();
		}
	}

}
