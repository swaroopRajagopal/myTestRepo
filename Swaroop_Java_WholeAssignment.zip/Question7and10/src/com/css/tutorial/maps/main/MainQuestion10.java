package com.css.tutorial.maps.main;

import java.util.ArrayList;
import java.util.HashMap;

import com.css.tutorial.maps.dto.Employee;

public class MainQuestion10 {
	
	
	public static void main(String[] args) {
//Creating a unique collection. 
		ArrayList<Employee> employeeList= new ArrayList<>();
		employeeList.add(new Employee("Amy","Samey1234" , "1234"));
		employeeList.add(new Employee("Clair","clr1234" , "1235"));
		employeeList.add(new Employee("Tim","mit589" , "1234"));
		employeeList.add(new Employee("James","jam894" , "1235"));
		employeeList.add(new Employee("Tina","tin1561" , "1235"));
		employeeList.add(new Employee("Sam","mas158" , "1235"));
		for(Employee e:employeeList)
			System.out.println(e);
		
//Counting Based on Department Number. 		
		HashMap<String,Integer> count = new HashMap<>();
		count.put("1234", 0);
		count.put("1235", 0);
		for(Employee e: employeeList) {
			if(e.getDeptNO().equals("1234")) {
				count.put("1234",count.get("1234")+1);
			}else if(e.getDeptNO().equals("1235")) {
				count.put("1235",count.get("1235")+1);
			}
		}
		System.out.println("\nNumber of Employees in each department: "+count);
	}
}
