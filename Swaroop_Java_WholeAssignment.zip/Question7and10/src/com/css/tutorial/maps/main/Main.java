package com.css.tutorial.maps.main;

import java.util.HashMap;

import com.css.tutorial.maps.dto.*;

public class Main {

	
	public static void main(String[] args) {
	
//	Create Employee
	
		
//	Creating a hashtable of Employee to later add to myCompany.

		HashMap<String, Employee> employeeMap = new HashMap<>();
	
		employeeMap.put(String.valueOf(1), new Employee( "Sam", "abcd123", "1234"));
		employeeMap.put(String.valueOf(2), new Employee( "Sam", "abcd123", "1234"));
		employeeMap.put(String.valueOf(3), new Employee( "Sam", "abcd123", "1234"));
//	Instantiate Company, and create a MAP of Employee
	
		Company myCompany = new Company("Axis101", "321B,BakerStreet", employeeMap);
		
//		CRUD Operations
		
//		1.Create. 
//		myCompany.createEmployee(name, password, deptNO);
		myCompany.createEmployee("Joey","joe1234","1234");
		System.out.println(myCompany);
//		2.Read.
//		myCompany.readEmployee(empID)
		myCompany.readEmployee(String.valueOf(2));
		System.out.println(myCompany);
//		3.Update.
//		myCompany.updateEmployee(name,password,department)
		myCompany.updateEmployee(String.valueOf(3),"Sara","sar1234","1234");
		System.out.println(myCompany);
//		4.Delete. 
//		myCompany.deleteEmployee(empID)		
		myCompany.deleteEmployee(String.valueOf(1));
		System.out.println(myCompany);
		
		
	}	
}
