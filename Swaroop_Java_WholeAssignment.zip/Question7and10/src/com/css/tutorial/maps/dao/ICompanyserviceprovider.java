package com.css.tutorial.maps.dao;
import com.css.tutorial.maps.dto.*;
public interface ICompanyserviceprovider {

	public boolean createEmployee(String employeeName, String password, String deptNO);
	public Employee readEmployee(String employeeID);
	public boolean updateEmployee(String employeeID,String employeeName, String password, String deptNO);
	public boolean deleteEmployee(String employeeID);
	
	
	
}
