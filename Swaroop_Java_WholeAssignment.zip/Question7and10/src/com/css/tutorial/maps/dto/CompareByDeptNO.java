package com.css.tutorial.maps.dto;

import java.util.Comparator;

public class CompareByDeptNO implements Comparator<Employee>{

	
	@Override
	public int compare(Employee e1, Employee e2) {
		if(Integer.valueOf(e1.getDeptNO()) > Integer.valueOf(e2.getDeptNO())){
			return 1;
		} else {
			return -1;
		}
	}
	
	

}
