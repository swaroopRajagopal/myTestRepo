package com.css.tutorial.maps.dto;

public class Employee {

	private String employeeID;
	private String employeeName;
	private String password;
	private String deptNO;
	private static int count=0;
//	Constructors
	public Employee(String employeeID, String employeeName, String password, String deptNO) {
		super();
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.password = password;
		this.deptNO = deptNO;
	}
	public Employee( String employeeName, String password, String deptNO) {
		super();
		this.employeeID = String.valueOf(++count);
		this.employeeName = employeeName;
		this.password = password;
		this.deptNO = deptNO;
	}
//	Getters and Setters
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDeptNO() {
		return deptNO;
	}
	public void setDeptNO(String deptNO) {
		this.deptNO = deptNO;
	}
	
//	Override toString()
	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", employeeName=" + employeeName + ", password=" + password
				+ ", deptNO=" + deptNO + "]";
	}
//	@Override
//	public int compareTo(Employee m) {
//		
//		if(Integer.valueOf(this.getDeptNO()) == Integer.valueOf(m.getDeptNO())) {
//			return 0;
//		}else if(Integer.valueOf(this.getDeptNO()) > Integer.valueOf(m.getDeptNO())) {
//			return 1;
//		}else 
//			return -1;
////		}
//	@Override
//	public int compare(Employee arg0, Employee arg1) {
//		// TODO Auto-generated method stub
//		return 0;
//	}		
}

	
////	Count and sort based on Department NO
//	public HashSet<Employee> CountEmp() {
//		
//		
//		return null;
//	}
	

