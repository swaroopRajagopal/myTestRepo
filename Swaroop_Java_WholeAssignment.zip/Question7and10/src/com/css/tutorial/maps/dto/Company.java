package com.css.tutorial.maps.dto;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import com.css.tutorial.maps.dao.ICompanyserviceprovider;

public class Company implements ICompanyserviceprovider {

	private String companyID;
	private String address;
	private HashMap<String, Employee> employeeMap;
	
//	Constructor
	public Company(String companyID, String address, HashMap<String, Employee> employeeMap) {
		super();
		this.companyID = companyID;
		this.address = address;
		this.employeeMap = employeeMap;
	}
	
//	Getters and Setters
	public String getCompanyID() {
		return companyID;
	}


	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public HashMap<String, Employee> getEmployeeMap() {
		return employeeMap;
	}

	public void setEmployeeMap(HashMap<String, Employee> employeeMap) {
		this.employeeMap = employeeMap;
	}

//	Override ToString
	@Override
	public String toString() {
		return "Company [companyID=" + companyID + ", address=" + address + ", employeeMap=" + employeeMap + "]";
	}
	
	
@Override
public boolean createEmployee(String employeeName, String password, String deptNO) {
	Employee newEmployee = new Employee(employeeName, password, deptNO);
	this.employeeMap.put(newEmployee.getEmployeeID(), newEmployee);
	return false;
}

@Override
public Employee readEmployee(String employeeID) {
	for(Map.Entry m : this.employeeMap.entrySet()) {
		if(m.getKey().equals(employeeID)) {
			return (Employee) m.getValue();
		}	
	}
	return null;
}
@Override
public boolean updateEmployee(String employeeID,String employeeName, String password, String deptNO) {
	Employee oldEmployee = readEmployee(employeeID);
	Employee newEmployee = new Employee(employeeID, employeeName, password, deptNO);
	boolean updateFlag=false;
	if(oldEmployee !=null) {
		this.employeeMap.replace(employeeID, oldEmployee, newEmployee);			
		updateFlag=true;
	}
	return updateFlag;
}
@Override
public boolean deleteEmployee(String employeeID) {
	boolean deleteFlag =false;
	if(readEmployee(employeeID)!=null) {
		this.employeeMap.remove(employeeID);
		deleteFlag=true;
	}
	return deleteFlag;
}



}
