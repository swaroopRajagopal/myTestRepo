package com.css.tutorial.bank_assignment.dto;

public class BankAccount {

	private String accountNo;
	private String accountName;
	private double balance;
	
//	Creating a static variable for bank account numbers. 
	private static int lastAssignedNo;
//	The parametrised constructor accepting all the variables. 
	
	static{
		lastAssignedNo=0;
	}
	
//	We can directly assign the value to the account NO in the constructor. So the method is redundant. 
	
//	public static String accountNumber(){
//		return String.valueOf(lastAssignedNo++);
//	}
	
	{
		balance = 1000; 
	}
	
//	Constructor accepting all parameters. 
	
	public BankAccount(String accountNo, String accountName, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.balance = balance;
	}
	
//	Overloaded constructor to accept only the account Number and Name.

	public BankAccount(String accountNo, String accountName) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.balance = 1000;
	}
	
	
//	Modifying the constructor to automatically calculate the account number. 
	public BankAccount(String accountName) {
		super();
		this.accountNo = String.valueOf(++lastAssignedNo);
		this.accountName = accountName;
	}

//	Getters and Setters. 
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

//  To sting. 
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountName=" + accountName + ", balance=" + balance + "]";
	}
	
	
}
