package com.css.tutorial.bank_assignment.dto;

import java.util.Arrays;

import com.css.tutorial.bank_assignment.dao.IBankServiceProvider;

public class Bank implements IBankServiceProvider {

	
//	Adding IFSC code and Bank Name from the lecture. 
	private String IFSC;
	private String bankName;
	
	private BankAccount[] bankAccountArray;
	

		
//	Constructor including IFSC and Bank Name
	
	public Bank(String iFSC, String bankName, BankAccount[] bankAccountArray) {
		super();
		IFSC = iFSC;
		this.bankName = bankName;
		this.bankAccountArray = bankAccountArray;
	}
	
//	To populate with setters.
	
	public Bank(String iFSC, String bankName) {
		super();
		IFSC = iFSC;
		this.bankName = bankName;
	}
	
	public Bank(BankAccount[] bankAccountArray) {
		super();
		this.bankAccountArray = bankAccountArray;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
//	Gettes and setters for the IFSC and Name. 
	
	

	public String getIFSC() {
		return IFSC;
	}

	public void setIFSC(String iFSC) {
		IFSC = iFSC;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	public void setBankAccountArray(BankAccount[] bankAccountArray) {
		this.bankAccountArray = bankAccountArray;
	}
	
	public BankAccount[] getBankAccountArray() {
		return bankAccountArray;
	}

	@Override
	public String toString() {
		return "Bank [bankAccountArray=" + Arrays.toString(bankAccountArray) + "]";
	}

	@Override
	public BankAccount checkAccount(String accountNO) {
		BankAccount foundAccount = null;
		for(BankAccount myAccount : this.bankAccountArray ) {
			if(myAccount.getAccountNo() .equals(accountNO)) {
				foundAccount=myAccount;
				break;
			}
		}
		return foundAccount;
	}

	@Override
	public double getBalance(String accountNO) {
		if(this.checkAccount(accountNO)!=null){
			return checkAccount(accountNO).getBalance();
		}else {			
			System.out.println("Account Number is invalid.");
			return 0;
		}		
	}

	@Override
	public boolean depositMoney(BankAccount account, double amount) {
		if(this.checkAccount(account.getAccountNo())!=null) {	
			account.setBalance(account.getBalance()+amount);
			return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean withdrawMoney(BankAccount account, double amount) {
		if(this.checkAccount(account.getAccountNo())!=null && account.getBalance()>=amount ) {
			account.setBalance(account.getBalance()-amount);
			return true;
		}else {
			return false;
		}
	}
	@Override
	public boolean transferMoney(BankAccount fromAccount, BankAccount toAccount, double amount) {
		boolean transferFlag = false;
		
		boolean withdrawFlag= this.withdrawMoney(fromAccount, amount);
		if(withdrawFlag) {
			boolean depositFlag= this.depositMoney(toAccount, amount);
			if(depositFlag)
				transferFlag=true;
			else
				this.depositMoney(fromAccount, amount);
		}
		return transferFlag;
	}
}
