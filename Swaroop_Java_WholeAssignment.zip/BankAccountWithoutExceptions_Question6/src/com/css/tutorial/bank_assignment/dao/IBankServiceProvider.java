package com.css.tutorial.bank_assignment.dao;

import com.css.tutorial.bank_assignment.dto.BankAccount;

public interface IBankServiceProvider {

	public BankAccount checkAccount(String accountNO);
	double getBalance(String accountNo);
	boolean depositMoney(BankAccount account, double amount);
	boolean withdrawMoney(BankAccount account,double amount);
	boolean transferMoney(BankAccount fromAccount,BankAccount toAccount, double amount);
	
	
}
