package com.css.tutorial.bank_assignment.main;

import com.css.tutorial.bank_assignment.dto.*;

public class Main {

	public static void main(String[] args) {

//		******************* Question 5.1 ***********
		
//		Creating a test Bank account. 
//		BankAccount[] testArray = new BankAccount[2];
//		testArray[0] = new BankAccount("1234", "Joe");
//		testArray[1] = new BankAccount("1235", "Sam");
//
////		populating the bankAccountArray using setters. 
//		Bank myBankAccount = new Bank();
//		myBankAccount.setBankAccountArray(testArray);
//		System.out.println(myBankAccount);
		
//		********************* Question 5.2 *************
//		Creating bank account with name. Account NO is automatically generated. 
		
		BankAccount[] bankAccountArray = new BankAccount[3];
		bankAccountArray[0]= new BankAccount("Sara");
		bankAccountArray[1]= new BankAccount("Joe");
		bankAccountArray[2]= new BankAccount("Sam");

//		Assigning the bank account array to the Bank. 
		Bank myBank = new Bank("Axis001","Axis Bank");
		myBank.setBankAccountArray(bankAccountArray);
		
//		********************** Question 5.3 ***************
//		Displaying Bank Accounts. 
		for(BankAccount account: myBank.getBankAccountArray() ) {
		System.out.println(account.toString());
		}
//		Check if Account number exists. 
		BankAccount checkAccount = myBank.checkAccount(""+1);
		if(checkAccount!= null) {
			System.out.println("\nAccount Found: \n     Account Number: "+checkAccount.getAccountNo()+"\n     Account Holders Name: "+checkAccount.getAccountName());	
		}else {
			System.out.println("Account Not found.\n");
		}
		
//		Get Balance
		if(checkAccount!=null) {
			System.out.println("\n     The account Balance is: "+myBank.getBalance(checkAccount.getAccountNo())+"\n");
		}
		int amt = 100; 
//		Deposit Money
		myBank.depositMoney(checkAccount, amt);
		System.out.println("You have deposited an amount of " +amt+".\nThe current balance is: " +checkAccount.getBalance()+"\n");
		
		amt=200;
//		Withdraw Money
		myBank.withdrawMoney(checkAccount, 200);
		System.out.println("You have withdrawn an amount of " +amt +".\nThe current balance is: "+checkAccount.getBalance()+"\n");
		
//		Transfer Money
		myBank.transferMoney(bankAccountArray[0], bankAccountArray[1], amt);
		System.out.println("Funds have been transfered.");
		System.out.println("The balance of the senders account: "+bankAccountArray[0].getBalance());
		System.out.println("The balance of the recipiants account: " +bankAccountArray[1].getBalance());		
	}
}
